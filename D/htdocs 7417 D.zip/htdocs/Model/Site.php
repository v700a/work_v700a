<?php

namespace Model;

use \Library\ConnectionPDO;

class Site
{

    function find_all($table)
    {
        $pdo = ConnectionPDO::getInstance()->getPDO();
        $re = $pdo->query("SELECT * FROM $table");
        $w = $re->fetch(\PDO::FETCH_ASSOC);
        return $w;
    }
    function find_count_all($table)
    {
        $pdo = ConnectionPDO::getInstance()->getPDO();
        $re = $pdo->query("SELECT COUNT(*) as count FROM $table");
        $w = $re->fetch(\PDO::FETCH_ASSOC);
        return $w['count'];
    }

    function find_search_count_all($table, $search_string)
    {
        $pdo = ConnectionPDO::getInstance()->getPDO();
        if ($table == 'book'):
        $re = $pdo->query("SELECT COUNT(*) as count FROM $table WHERE title LIKE '%$search_string%' 
                          OR description LIKE '%$search_string%'");
        else:
        $re = $pdo->query("SELECT COUNT(*) as count FROM $table WHERE title LIKE '%$search_string%' 
                          OR content LIKE '%$search_string%'");
        endif;
        $w = $re->fetch(\PDO::FETCH_ASSOC);
        return $w['count'];
    }

    function find_search_all($table, $search_string)
    {
        $pdo = ConnectionPDO::getInstance()->getPDO();
        if ($table == 'book'):
        $re = $pdo->query("SELECT * FROM $table WHERE title LIKE '%$search_string%' 
                          OR description LIKE '%$search_string%'");
        else:
        $re = $pdo->query("SELECT * FROM $table WHERE title LIKE '%$search_string%' 
                          OR content LIKE '%$search_string%'");
        endif;
        $w = $re->fetchAll(\PDO::FETCH_ASSOC);
        return $w;
    }

    function find_count_all_sort_by($sort, $sortValue)
    {
        $pdo = ConnectionPDO::getInstance()->getPDO();

        $re = $pdo->query("SELECT FROM book");

        if ($sort == 'sortById' && $sortValue == 'down'):
            $re = $pdo->query("SELECT * FROM book ORDER BY id DESC");
        elseif ($sort == 'sortByTitle' && $sortValue == 'down'):
            $re = $pdo->query("SELECT * FROM book ORDER BY title DESC");
        elseif ($sort == 'sortByPrice' && $sortValue == 'down'):
            $re = $pdo->query("SELECT * FROM book ORDER BY price DESC");
        elseif ($sort == 'sortByActive' && $sortValue == 'down'):
            $re = $pdo->query("SELECT * FROM book ORDER BY is_active DESC");
        endif;

        if ($sort == 'sortById' && $sortValue == 'up'):
            $re = $pdo->query("SELECT * FROM book ORDER BY id");
        elseif ($sort == 'sortByTitle' && $sortValue == 'up'):
            $re = $pdo->query("SELECT * FROM book ORDER BY title");
        elseif ($sort == 'sortByPrice' && $sortValue == 'up'):
            $re = $pdo->query("SELECT * FROM book ORDER BY price");
        elseif ($sort == 'sortByActive' && $sortValue == 'up'):
            $re = $pdo->query("SELECT * FROM book ORDER BY is_active");
        endif;
        $w = $re->fetch(\PDO::FETCH_ASSOC);
        return $w;
    }

    function read_limit($db, $count, $limit=1, $page = 0, $sort = '', $sortValue = '')
    {
        $pdo = ConnectionPDO::getInstance()->getPDO();
        if ($page !== 0):
            $offset = ($page - 1) * $limit;
        else:
            $offset = $page;
        endif;
        $c = round($count/$limit);
        $sortField = 'time_stamp';
        $sortType = 'DESC';

        $result_query_find = $pdo -> query("SELECT * FROM $db ORDER BY $sortField $sortType LIMIT $offset, $limit");
        return $result_query_find->fetchAll(\PDO::FETCH_ASSOC);
    }


    function find_by_id($id, $table)
    {
        $pdo = ConnectionPDO::getInstance()->getPDO();
        $sql_query_string_find = $pdo->prepare("SELECT * FROM $table WHERE id = :id");
        $sql_query_string_find->execute(compact('id'));
        return $sql_query_string_find->fetch(\PDO::FETCH_ASSOC);
    }

    function remove_by_id($id)
    {
        $pdo = ConnectionPDO::getInstance()->getPDO();
        $sql_query_string_find = $pdo->prepare("DELETE FROM book WHERE id = :id");
        $sql_query_string_find->execute(compact('id'));
        return $sql_query_string_find;
    }

    function find_count_feed_by_id($id_news, $category)
    {
        $pdo = ConnectionPDO::getInstance()->getPDO();
        $sql_query_string_find = $pdo->query("SELECT COUNT(*) AS 'count' FROM feedback WHERE category_news = '$category' 
                                AND id_news = '$id_news'");
        $count = $sql_query_string_find->fetch(\PDO::FETCH_ASSOC);
        if ($sql_query_string_find !== false):
            return $count;
        else:
            return null;
        endif;
    }
    function find_feed_by_id($id_news, $category)
    {
        $pdo = ConnectionPDO::getInstance()->getPDO();
        $sql_query_string_find = $pdo->query("SELECT * FROM feedback WHERE category_news = '$category' AND id_news = '$id_news'
        ORDER BY `feedback`.`time_stamp` DESC");
        if ($sql_query_string_find !== false):
           return $sql_query_string_find->fetchAll(\PDO::FETCH_ASSOC);
        else:
           return null;
        endif;
    }


    function save_feed_by_id(array $update_feed)
    {
        $pdo = ConnectionPDO::getInstance()->getPDO();
        if (isset($update_feed['update'])):
            $insert_feed_user_comment = $update_feed['feed'];
            $insert_feed_user_comment = str_replace("\\", "\\\\", $insert_feed_user_comment);
            $insert_feed_id = $update_feed['id_'];
            $sql_query_string_update = $pdo->prepare("UPDATE feedback SET user_comment = :insert_feed_user_comment
                                  WHERE id = :insert_feed_id");
            $sql_query_string_update->execute(compact('insert_feed_user_comment','insert_feed_id'));
        else:
//            if (isset($update_feed['title'])):
//                if ($update_feed['title'] !== '' && $update_feed['title'] !== null):
//        echo 555555555555555;
//        var_dump($update_feed);
//        var_dump($pdo);
                    $insert_feed_id_news = $update_feed['id_news'];
                    $insert_feed_category_news = $update_feed['category_news'];
                    $insert_feed_id_user = $update_feed['id_user'];
                    $insert_feed_user_comment = $update_feed['feed'];
                    $insert_feed_user_comment = str_replace("\\", "\\\\", $insert_feed_user_comment);
                    $insert_feed_user_rating_user = 0; //$update_feed['feed'];
                    $insert_feed_name_user = $update_feed['name_user'];

                    $sql_query_string_insert = $pdo->prepare("INSERT INTO feedback (id_news, category_news, id_user, user_comment,
                        rating_user, name_user) VALUES ( :insert_feed_id_news, :insert_feed_category_news, :insert_feed_id_user,
                        :insert_feed_user_comment, :insert_feed_user_rating_user, :insert_feed_name_user)");
                    $sql_query_string_insert->execute(compact('insert_feed_id_news', 'insert_feed_category_news',
                        'insert_feed_id_user', 'insert_feed_user_comment', 'insert_feed_user_rating_user', 'insert_feed_name_user'));
//                endif;
//            endif;
        endif;
    }

    function remove_feed_by_id($id)
    {
        $pdo = ConnectionPDO::getInstance()->getPDO();
        $sql_query_string_find = $pdo->prepare("DELETE FROM feedback WHERE id = :id");
        $sql_query_string_find->execute(compact('id'));
        return $sql_query_string_find;
    }

}

