<?php
namespace Library;

class DbConnection
{
    private $pdo;
    
    public function __construct($dsn, $user, $pass)
    {
        $this->pdo = new \PDO($dsn, $user, $pass);
        $this->pdo->setAttribute(\PDO::ATTR_ERRMODE, \PDO::ERRMODE_EXCEPTION);
    }
    
    public function getPDO()
    {
        return $this->pdo;
    }
    
    
    // public static function getInstance()
    // {
    //     if (self::$instance === null) {
    //         self::$instance = new DbConnection('mysql:host=localhost;dbname=mvc','root',''); 
    //     }
        
    //     return self::$instance; 
    // }
}
