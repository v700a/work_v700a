<?php

namespace Controller;

use \Library\Controller;
use Library\Session;
use \Model\Book;
use \Library\Request;

class BookController extends Controller
{
    public static $limit = 10;
    public static $page = 0;

    //function indexAction ($limit = 20, $page = 0)
    function indexAction ($request)
    {
        if (Session::get('count') == null):
            Session::set('count', 10);
        endif;
        if ($request->isGetOf('count') !== null):
            Session::set('count', $request->isGetOf('count'));
        endif;
        $limit_ = Session::get('count');
        $book = new Book();
        $count = $book->find_count_all();

        $array_book = $book->read_limit($count, $limit_, self::$page);
        $count_pages_pre = $count/$limit_;
        $count_pages = round($count/$limit_);
        if ($count_pages_pre > $count_pages):
            $count_pages = $count_pages + 1;
        endif;
        $array = array(
            'array_book' => $array_book,
            'count_pages' => $count_pages
        );
        return $this->render('index.phtml', $array);
    }

    function addAction ($request, $page=0)
    {
        $book = new Book();
        $style_arr = $book->find_all_style();
        $array = $style_arr;
        return $this->render('add.phtml', $array);
    }

    function editAction ($request, $id = null, $page = 0)
    {
        if ($id == null):
            throw new \Exception();
        else:
            $book = new Book();
            $count = $book->find_count_all();
            $array_book = $book->find_by_id($id);
            $count_pages = round($count/self::$limit);
            $array = array(
                'array_book' => $array_book,
                'count_pages' => $count_pages
            );
            return $this->render('edit.phtml', $array);
        endif;
    }

    function saveAction ($request, $page = 0)
    {
//        var_dump($request);
        if ($request['title'] == ''):
            $array = array();
            return $this->render('add.phtml', $array);
        endif;
        $book = new Book();
        $book->save_by_id($request);
        $count = $book->find_count_all();
        $array_book = $book->read_limit($count, self::$limit, self::$page);
        $count_pages = round($count/self::$limit);
        $array = array(
            'array_book' => $array_book,
            'count_pages' => $count_pages
        );
        return $this->render('index.phtml', $array);
    }


    function deleteAction ($request=[], $id = null, $page_current = 0)
    {
        if ($id == null):
            throw new \Exception();
        else:
            $book = new Book();
            $book->remove_by_id($id);
            $count = $book->find_count_all();
            $array_book = $book->read_limit($count, self::$limit, self::$page);
            $count_pages = round($count/self::$limit);
            $array = array(
                'array_book' => $array_book,
                'count_pages' => $count_pages,
                'page_current' => $page_current
            );
            return $this->render('index.phtml', $array);
        endif;
    }
    function readAction ($request, $id = null)
    {
        if ($id == null):
            throw new \Exception();
        else:
            $book = new Book();
            $count = $book->find_count_all();
            $array_book = $book->find_by_id($id);
            $count_pages = round($count/self::$limit);
            $array = array(
                'array_book' => $array_book,
                'count_pages' => $count_pages
            );

            return $this->render('read.phtml', $array);
        endif;
    }
    function sortAction ($request)
    {
        $book = new Book();
        $limit_sort = Session::get('count');
//        $request = new Request();
        $count = $book->find_count_all();
        $array_book = $book->read_limit($count, $limit_sort, self::$page);
        if ($request->isGetOf('sortById') == 'down'):
            $sortField = 'sortById';
            $sortType = 'down';
            $array_book = $book->read_limit($count, $limit_sort, self::$page, $sortField, $sortType);
        elseif ($request->isGetOf('sortByTitle') == 'down'):
            $sortField = 'sortByTitle';
            $sortType = 'down';
            $array_book = $book->read_limit($count, $limit_sort, self::$page, $sortField, $sortType);
        elseif ($request->isGetOf('sortByStyle') == 'down'):
            $sortField = 'sortByStyle';
            $sortType = 'down';
            $array_book = $book->read_limit($count, $limit_sort, self::$page, $sortField, $sortType);
        elseif ($request->isGetOf('sortByAuthor') == 'down'):
            $sortField = 'sortByAuthor';
            $sortType = 'down';
            $array_book = $book->read_limit($count, $limit_sort, self::$page, $sortField, $sortType);
        elseif ($request->isGetOf('sortByPrice') == 'down'):
            $sortField = 'sortByPrice';
            $sortType = 'down';
            $array_book = $book->read_limit($count, $limit_sort, self::$page, $sortField, $sortType);
        elseif ($request->isGetOf('sortByActive') == 'down'):
            $sortField = 'sortByActive';
            $sortType = 'down';
            $array_book = $book->read_limit($count, $limit_sort, self::$page, $sortField, $sortType);
        endif;

        if ($request->isGetOf('sortById') == 'up'):
            $sortField = 'sortById';
            $sortType = 'up';
            $array_book = $book->read_limit($count, $limit_sort, self::$page, $sortField, $sortType);
        elseif ($request->isGetOf('sortByTitle') == 'up'):
            $sortField = 'sortByTitle';
            $sortType = 'up';
            $array_book = $book->read_limit($count, $limit_sort, self::$page, $sortField, $sortType);
        elseif ($request->isGetOf('sortByStyle') == 'up'):
            $sortField = 'sortByStyle';
            $sortType = 'up';
            $array_book = $book->read_limit($count, $limit_sort, self::$page, $sortField, $sortType);
        elseif ($request->isGetOf('sortByAuthor') == 'up'):
            $sortField = 'sortByAuthor';
            $sortType = 'up';
            $array_book = $book->read_limit($count, $limit_sort, self::$page, $sortField, $sortType);
        elseif ($request->isGetOf('sortByPrice') == 'up'):
            $sortField = 'sortByPrice';
            $sortType = 'up';
            $array_book = $book->read_limit($count, $limit_sort, self::$page, $sortField, $sortType);
        elseif ($request->isGetOf('sortByActive') == 'up'):
            $sortField = 'sortByActive';
            $sortType = 'up';
            $array_book = $book->read_limit($count, $limit_sort, self::$page, $sortField, $sortType);
        endif;


//        $array_book = $book->read_limit($count, self::$limit, self::$page);
        $count_pages = round($count/self::$limit);
        $array = array(
            'array_book' => $array_book,
            'count_pages' => $count_pages
        );

        return $this->render('index.phtml', $array);

    }
}