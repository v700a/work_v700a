<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace Traits;

use \Library\ConnectionPDO;

/**
 * Description of Models
 *
 * @author Victor
 */
trait Models {

   function find_all()
    {
        $pdo = ConnectionPDO::getInstance()->getPDO();
        $t = self::$table;
        $result_query_find = $pdo -> query("SELECT * FROM $t ");
        return $result_query_find->fetchAll(\PDO::FETCH_ASSOC);
    }

    function find_count_all()
    {
        $pdo = ConnectionPDO::getInstance()->getPDO();
        $re = $pdo->query("SELECT COUNT(*) as count FROM book");
        $w = $re->fetch(\PDO::FETCH_ASSOC);
        return $w['count'];
    }
 
    function find_by_id($id)
    {
        $pdo = ConnectionPDO::getInstance()->getPDO();
        $sql_query_string_find = $pdo->query("SELECT * FROM book LEFT JOIN style ON style.id_style = book.style_id
                                                LEFT JOIN book_author ON book_author.book_id = book.id
                                                LEFT JOIN author ON author.id_author = book_author.author_id
                                                WHERE id = $id GROUP BY book.id");
        return $sql_query_string_find->fetch(\PDO::FETCH_ASSOC);
    }

    function remove_by_id($id)
    {
//        $id = $id->isGetOf('id');
        $pdo = ConnectionPDO::getInstance()->getPDO();
        $sql_query_string_find = $pdo->prepare("DELETE FROM book WHERE id = :id");
        $sql_query_string_find->execute(compact('id'));
        return $sql_query_string_find;
    }
 
    function find_all_style()
    {
        $pdo = ConnectionPDO::getInstance()->getPDO();
        $re = $pdo->query("SELECT * FROM style");
        $st = $re->fetchAll(\PDO::FETCH_ASSOC);
        return $st;
    }
   
}
