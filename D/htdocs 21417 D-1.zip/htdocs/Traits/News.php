<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace Traits;

/**
 * Description of TraitNews
 *
 * @author Victor
 */
trait News {
    
    function indexAction ($request)
    {
        $site = new \Model\Site();
        $count = $site->find_count_all(self::$category);
        $array_site = $site->read_limit(self::$category, $count, self::$limit, self::$page);
        $count_pages = round($count/self::$limit);
        $array = array(
                self::$category => $array_site,
                'count_pages' => $count_pages
            );
        return $this->render('index.phtml', $array);
    }

    function readAction ($request, $id = null)
    {
        if ($id == null):
            throw new \Exception();
        else:
            $s = new \Model\Site();
            if (isset($_SESSION['username_in'])):
                $d = explode('-', $_SESSION['username_in']);
                $name_user = $d['0'];
            endif;
            $id_news_feed = $request->isGetOf('description');
            $id_news = $request->isPostOf('id_news');
            $feed = strip_tags($request->isPostOf('feed'));
            $category_news = $request->isPostOf('category_news');
            $id_user = $request->isPostOf('id_user');
            echo $id_user;
            $update = $request->isPostOf('update');
            $delete = $request->isPostOf('delete');
            $id_ = $request->isPostOf('id');
            if ($delete == 'delete'):
                $s->remove_feed_by_id($id_);
            endif;
            if ($feed !== null && $feed !== ''):
                $array_feed_for_save = array(
                   'id_news' =>  $id_news,
                   'feed' => $feed,
                   'category_news' => $category_news,
                   'id_user' => $id_user,
                   'update' => $update,
                   'name_user' => $name_user,
                    'id_' => $id_
                );

                $s->save_feed_by_id($array_feed_for_save);
            endif;
            $array_s = $s->find_by_id($id, self::$category);
            $count_comment = $s->find_count_feed_by_id($id_news_feed, self::$category);
            $array_feed = $s->find_feed_by_id($id_news_feed, self::$category);
            $array = array(
                'array_s' => $array_s,
                'array_feed' => $array_feed,
                'count_comment' => $count_comment
            );

            return $this->render('read.phtml', $array);
        endif;
    }
   
}
