<?php
/**
 * Created by PhpStorm.
 * User: Victor
 * Date: 02.03.2017
 * Time: 13:05
 */

namespace Controller;

use Library\Controller;
//use Model\Site;


class ScienceController extends Controller
{
    public static $limit = 10;
    public static $page = 0;
    public static $category = 'science';

    use \Traits\News;

}