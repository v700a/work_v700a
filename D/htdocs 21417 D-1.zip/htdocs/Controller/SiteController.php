<?php

namespace Controller;

use \Library\Controller;
//use \Library\Functions;
use Library\Session;
use Model\Site;
use \Model\User;
use \Library\Request;

class SiteController extends Controller
{
    public static $limit = 5;
    public static $page = 0;

    function indexAction ()
    {
        $array = array();
        return $this->render('index.phtml', $array);
    }

    function loginAction ($request)
    {
        $user_model = new User();
        $logerr = null;
        if (Session::getContent('logmsg') == 'log_err'):
            $logerr = "Помилка авторизації! Невірний Логін/Пароль!";
            Session::remove('logmsg');
        endif;
        $login = 0;
        $login_and_id_user = 0;
        if(!isset($_SESSION['username_in'])):
            if ((parent::isLoginFormValid ('login', 'password')) !== null) :
                $login = $request->isPostOf('login');
                $password = md5($request->isPostOf('password') . 'phpsalt');
                $db_users = $user_model->find($login, $password);
                $login_and_id_user = $login . '-' . $db_users['id'] . '-' . $db_users['city'];
                if ($db_users) :
                    Session::setContent('username_in', $login_and_id_user);
                    header('location: index.php?route=site/login');
                    die;
                endif;
                Session::setContent('logmsg','log_err');
                header('location: index.php?route=site/login');
                die;
            endif;
        endif;
        if (Session::getContent('logmsg') == 'out'):
            Session::remove('username_in');
            Session::remove('logmsg');
        endif;

        $array = array( 'logerr' => $logerr);

        return $this->render('login.phtml', $array);

    }

    function registerAction (Request $request)
    {
        $user_model = new User();
//        if (Session::getContent('REQUEST_URI') == null):
//            Session::setContent('REQUEST_URI', $_SERVER['REQUEST_URI']);
//        elseif (Session::getContent('REQUEST_URI') !== $_SERVER['REQUEST_URI']):
//            Session::setContent('REQUEST_URI', $_SERVER['REQUEST_URI']);
//        endif;

        $sql_db = $user_model->find_all();
        if ($request->isMethod() == 'POST'):
            parent::isRegFormValid($sql_db);
        endif;
        $login_and_id_user = 0;

        if (Session::getContent('formOk') == 1):
            $login = strip_tags(Session::getContent('login'));
            $pass_md5 = md5(Session::getContent('password') . 'phpsalt');
            $email_ = strip_tags(Session::getContent('email'));
            $user_model->insert($login, $pass_md5, $email_);
            $db_users = $user_model->find($login, $password, $email);
            $login_and_id_user = $login . '-' . $db_users['id'] . '-' . $db_users['city'];
            Session::setContent('username_in', $login_and_id_user);
            Session::setContent('registered', "Ви зареєстровані як - {$login}.");
            header('location: index.php');
            die;
        endif;
        if ($_SERVER['REQUEST_METHOD'] == 'POST'):
            header('location: index.php?route=site/register');
            die;
        endif;

        $array = array();
        return $this->render('registration.phtml', $array);

    }

    function registerAjaxAction ()
    {
        $arr = array();
        $i = 0;
        $arrVal = $_POST['valuesArr'];
        foreach ($_POST['namesArr'] as $value):
            $arr[$value] = $arrVal[$i];
            $i++;
        endforeach;
        //var_dump($arr);

        $user_model = new User();

        $sql_db = $user_model->find_all();
        // if ($request->isMethod() == 'POST'):
        //     parent::isRegFormValid($sql_db);
        // endif;
        $error_ = 0;
        if ($sql_db !== null):
            foreach ($sql_db as $value):
                foreach ($value as $item):
                    if ($arr['login'] === $item):
                        echo 'login_err';
                        $error_ = 1;
                    endif;
                    if ($arr['email'] === $item):
                        echo 'email_err';
                        $error_ = 1;
                    endif;

                endforeach;
            endforeach;
        endif;

        $login_and_id_user = 0;

        if ($error_ == 0):
            $login = strip_tags($arr['login']);
            $pass_md5 = md5($arr['password'] . 'phpsalt');
            $email_ = strip_tags($arr['email']);
            $user_model->insert($login, $pass_md5, $email_);
            $db_users = $user_model->find($login, $pass_md5, $email_);
            $login_and_id_user = $login . '-' . $db_users['id'] . '-' . $db_users['city'];
            Session::setContent('username_in', $login_and_id_user);
            Session::setContent('registered', "Ви зареєстровані як - {$login}.");
            echo 'OK';
        endif;



        // $q = 'rrrRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR';
        // return $q;

    }

    function readAction ($request, $id = null)
    {
        if ($id == null):
            throw new \Exception();
        else:
            $book = new Site();
            $count = $book->find_count_all();
            $array_book = $book->find_by_id($id);
            $count_pages = round($count/self::$limit);
            $array = array(
                'array_book' => $array_book,
                'count_pages' => $count_pages
            );

            return $this->render('read.phtml', $array);
        endif;
    }


    function searchAction ($request)
    {
        $array = array();
        $count = 0;
        $search_string = strip_tags($request->isGetOf('search'));
            $array_db = array('business', 'policy', 'sport', 'science','vacation', 'book');
            foreach ($array_db as $value):
                $site = new Site();
                $count = $count + $site->find_search_count_all($value, $search_string);
                $array_search = $site->find_search_all($value, $search_string);
                $array[$value] = $array_search;
            endforeach;
            $count_pages = round($count/self::$limit);
            $array ['count_pages'] = $count_pages;
            $array ['search_count'] = $count;
            $array ['search_string'] = $search_string;
            return $this->render('search.phtml', $array);
    }


}
