<?php
/**
 * Created by PhpStorm.
 * User: Victor
 * Date: 02.03.2017
 * Time: 0:25
 */

namespace Controller;


use Library\Controller;
//use Library\Request;
//use Model\Site;


class BusinessController extends Controller
{


    public static $limit = 10;
    public static $page = 0;
    public static $category = 'business';

    use \Traits\News;

    

}

