<?php
/**
 * Created by PhpStorm.
 * User: Victor
 * Date: 02.03.2017
 * Time: 12:54
 */

namespace Controller;

use Library\Controller;
//use Model\Site;


class SportController extends Controller
{
    public static $limit = 10;
    public static $page = 0;
    public static $category = 'sport';

    use \Traits\News;

}