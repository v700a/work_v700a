<?php
/**
 * Created by PhpStorm.
 * User: Victor
 * Date: 02.03.2017
 * Time: 13:11
 */

namespace Controller;

use Library\Controller;
//use Model\Site;


class VacationController extends Controller
{
    public static $limit = 10;
    public static $page = 0;
    public static $category = 'vacation';

    use \Traits\News;

}