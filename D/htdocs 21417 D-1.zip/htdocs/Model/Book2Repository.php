<?php
/**
 * Created by PhpStorm.
 * User: Victor
 * Date: 05.02.2017
 * Time: 12:17
 */

namespace Model;

use Library\ConnectionPDO;


class Book2Repository
{

    use \Traits\Models;
        
    function find_count_all_sort_by($sort, $sortValue)
    {
        $pdo = ConnectionPDO::getInstance()->getPDO();

        $re = $pdo->query("SELECT FROM book");

        if ($sort == 'sortById' && $sortValue == 'down'):
            $re = $pdo->query("SELECT * FROM book ORDER BY id DESC");
        elseif ($sort == 'sortByTitle' && $sortValue == 'down'):
            $re = $pdo->query("SELECT * FROM book ORDER BY title DESC");
        elseif ($sort == 'sortByPrice' && $sortValue == 'down'):
            $re = $pdo->query("SELECT * FROM book ORDER BY price DESC");
        elseif ($sort == 'sortByActive' && $sortValue == 'down'):
            $re = $pdo->query("SELECT * FROM book ORDER BY is_active DESC");
        endif;

        if ($sort == 'sortById' && $sortValue == 'up'):
            $re = $pdo->query("SELECT * FROM book ORDER BY id");
        elseif ($sort == 'sortByTitle' && $sortValue == 'up'):
            $re = $pdo->query("SELECT * FROM book ORDER BY title");
        elseif ($sort == 'sortByPrice' && $sortValue == 'up'):
            $re = $pdo->query("SELECT * FROM book ORDER BY price");
        elseif ($sort == 'sortByActive' && $sortValue == 'up'):
            $re = $pdo->query("SELECT * FROM book ORDER BY is_active");
        endif;
        $w = $re->fetch(\PDO::FETCH_ASSOC);
        return $w;
    }

    function read_limit($count, $limit=1, $page = 0, $sort = 'sortById', $sortValue = 'none')
    {
        $pdo = ConnectionPDO::getInstance()->getPDO();
        if ($page !== 0):
            $offset = ($page - 1) * $limit;
        else:
            $offset = $page;
        endif;
        $c = round($count/$limit);
        $sortField = 'book.id';
        $sortType = '';

        if ($sort == 'sortById' && $sortValue == 'down'):
            $sortField = 'id';
            $sortType = 'DESC';
        elseif ($sort == 'sortByTitle' && $sortValue == 'down'):
            $sortField = 'title';
            $sortType = 'DESC';
        elseif ($sort == 'sortByPrice' && $sortValue == 'down'):
            $sortField = 'price';
            $sortType = 'DESC';
        elseif ($sort == 'sortByActive' && $sortValue == 'down'):
            $sortField = 'is_action';
            $sortType = 'DESC';
        endif;

        if ($sort == 'sortById' && $sortValue == 'up'):
            $sortField = 'id';
            $sortType = '';
        elseif ($sort == 'sortByTitle' && $sortValue == 'up'):
            $sortField = 'title';
            $sortType = '';
        elseif ($sort == 'sortByPrice' && $sortValue == 'up'):
            $sortField = 'price';
            $sortType = '';
        elseif ($sort == 'sortByActive' && $sortValue == 'up'):
            $sortField = 'is_action';
            $sortType = '';
        endif;

        $result_query_find = $pdo -> query("SELECT * FROM book LEFT JOIN style ON style.id_style = book.style_id
                                                LEFT JOIN book_author ON book_author.book_id = book.id
                                                LEFT JOIN author ON author.id_author = book_author.author_id
                                                GROUP BY book.id
                                                ORDER BY $sortField $sortType LIMIT $offset, $limit");
        $allBook = [];

        while ($book = $result_query_find->fetch(\PDO::FETCH_ASSOC)):
            $a = new Book2();
            $a->setTitle($book['title']);
            $a->setDescription($book['description']);
            $a->setStyleId($book['style_id']);
            $a->setNameStyle($book['name_style']);
            $a->setPrice($book['price']);
            $a->setIsActive($book['is_active']);
            $a->setId($book['id']);
            $a->setFirstName($book['first_name']);
            $a->setLastName($book['last_name']);
            $allBook [] = $a;
        endwhile;
        return $allBook;
    }


}
