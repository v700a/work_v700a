<?php

namespace Model;

use Library\ConnectionPDO;

class User
{
    public static $table = 'user';

    use \Traits\Models;

    
    function find($name, $pass, $email = null)
    {
        if ($email !== null):
            $pdo = ConnectionPDO::getInstance()->getPDO();
            $sql_query_string_find = $pdo->prepare("SELECT * FROM user WHERE name = :name AND password = :pass 
                                            AND email = :email");
            $sql_query_string_find->execute(compact('name', 'pass', 'email'));
            return $sql_query_string_find->fetch(\PDO::FETCH_ASSOC);
        else:
            $pdo = ConnectionPDO::getInstance()->getPDO();
            $sql_query_string_find = $pdo->prepare("SELECT * FROM user WHERE name = :name AND password = :pass");
            $sql_query_string_find->execute(compact('name', 'pass'));
            return $sql_query_string_find->fetch(\PDO::FETCH_ASSOC);
        endif;
    }

    function insert ($name, $pass, $email)
    {
        $pdo = ConnectionPDO::getInstance()->getPDO();
        $sql_query_string_insert = $pdo->prepare("INSERT INTO user (name, password, email) VALUES (:name, :pass, :email)");
        $sql_query_string_insert->execute(compact('name','pass','email'));
    }

}
