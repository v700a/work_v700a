<?php
/**
 * Created by PhpStorm.
 * User: Victor
 * Date: 14.12.2016
 * Time: 19:32
 */

namespace Model;


class Gallery
{


}