<?php
/**
 * Created by PhpStorm.
 * User: Victor
 * Date: 13.03.2017
 * Time: 17:54
 */

namespace Controller;

use Model\Site;
use Library\Controller;

class NewsController extends Controller
{
    public static $limit = 5;
    public static $page = 0;

    function indexAction ()
    {
        $array = array();
        $array_db = array('business', 'policy', 'sport', 'science','vacation');
        foreach ($array_db as $value):
            $site = new Site();
            $count = $site->find_count_all($value);
            $array_site = $site->read_limit($value, $count, self::$limit, self::$page);
            $array[$value] = $array_site;
        endforeach;
        return $this->render('index.phtml', $array);
    }

}