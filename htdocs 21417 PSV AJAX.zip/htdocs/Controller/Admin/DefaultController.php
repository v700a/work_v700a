<?php
namespace Controller\Admin;

use Library\Controller;
use Library\Request;
use Library\Router;
class DefaultController extends Controller
{
		public function indexAction(Request $request)
	{
		$router = new Router('routes.php');
		if(!isset($_COOKIE['admin']))
		{
			$router->redirect('/');
		}

		return $this->render('index.php');
	}
}