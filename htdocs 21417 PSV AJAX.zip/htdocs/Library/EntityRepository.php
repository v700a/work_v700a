<?php
namespace Library;
use Library\DbConnectionAwareTrait;
abstract class EntityRepository
{
 	
	use DbConnetionAwareTrait;

}