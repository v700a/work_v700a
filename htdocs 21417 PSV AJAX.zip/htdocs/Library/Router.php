<?php
namespace Library;

class Router
{
    private $map;
    public $controller = null;
    public $action = null;
    
    /**
     * @param $routesFile
     */
    public function __construct($routesFile)
    {
        $this->map = require(CONF_DIR . $routesFile);
    }
    
    /**
     * @param $uri
     * @return bool
     */
     
    private function isAdminUri($uri)
    {
        return strpos($uri, '/admin') === 0;
    }
    
    /**
     * @param Request $request
     * @throws \Exception
     */
    public function match(Request $request)
    {
        // вытаскиваем УРЛ без параметров
        $uri = $request->getURI();
        // если видим, что урл админский
        if ($this->isAdminUri($uri)) {
            Controller::setAdminLayout();
        }
        
        // перебор элементов массива из routes.php для сопоставления с $uri
        foreach ($this->map as $route) {
            
            // заготовка для регулярки
            $regex = $route->pattern;
            
            // меняем там наши {param} на реальные виражения регулярки из соотв. массива
            foreach ($route->params as $k => $v) {
                $regex = str_replace('{' . $k . '}', '(' . $v . ')', $regex);
                // echo "$regex <br>";
            }
            
            // если нашли совпадение по регулярному выражению
            if (preg_match('@^' . $regex . '$@', $uri, $matches)) {
                // выталкиваем первы елемент - не нужен. Тогда остается либо пустой массив, либо список из значений параметров
                array_shift($matches);
                // если не пустой, то докидываем их в ГЕТ, как-будто они реально ГЕТ параметры
                if ($matches) {
                    $matches = array_combine(array_keys($route->params), $matches);
                    $request->mergeGet($matches);
                }
                // допиливаем названия контроллера и действия
                $this->controller = 'Controller\\' . $route->controller;
                $this->action = $route->action . 'Action';
                break;
            }
        }
        
        // если не опеределен контроллер то исключение
        if (is_null($this->controller) || is_null($this->action)) {
            throw new \Exception('Route not found: ' . $uri, 404);
        }
    }
    
    /**
     * @param $to
     */
    public function redirect($to)
    {
        header('Location: ' . $to);
        die;
    }
    
    public function getRouteUri($routeName, array $params = array())
    {
    }
}