<?php

namespace Model;

use Library\EntityRepository;

class FeedbackRepository extends EntityRepository
{
	public function save(Feedback $feedback)
	{
		if($feedback->getId()) 
		{
			//mysql UPDATE ... WHERE id = $feedback->getId()
			return;
		}
		$sql = "
		INSERT INTO feedback (username, email, message, created, ip_adress)
		values(:username, :email, :message, :created, :ip_adress)
		";

		$pdo = $this->dbConnection->getPdo();
		$params = [
			'username' => $feedback->getUsername(),
			'email' => $feedback->getEmail(),
			'message' => $feedback->getMessage(),
			'created' => $feedback->getCreated()->format('Y-m-d H-i-s'),
			'ip_adress' => $feedback->getIpAdress(),
		];
		$sth = $pdo->prepare($sql);
		$sth->execute($params);

	}
}