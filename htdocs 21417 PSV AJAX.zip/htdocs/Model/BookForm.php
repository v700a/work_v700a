<?php
namespace Model;
use Library\Request;
class BookForm
{
    public $img;
    public $title;
    public $description;
    public $price;
    
    public function __construct(Request $request)
    {
        $this->title = $request->post('title');
        $this->description = $request->post('description');
        $this->price = $request->post('price');
    }
    
    public function isValid()
    {
        return $this->title != '' && $this->description != '' && $this->price != '';
    }
}