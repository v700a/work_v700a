<h1>Error</h1>
<?=$message?>